/*
 * Copyright (C) 2018, Liberty Mutual Group
 *
 * Created on Nov 27, 2018
 */

package com.taskmanager.tsk.dao;

import java.util.List;
import java.util.Optional;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.transaction.Transactional;

import org.springframework.data.domain.Example;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.taskmanager.tsk.entity.Tasks;

/**
 * @author n0136406
 *
 */
@Transactional
@Repository
public class TaskDAO implements ITaskDAO, JpaRepository<Tasks, Long> {
	@PersistenceContext	
	private EntityManager entityManager;

	/* (non-Javadoc)
	 * @see com.taskmanager.dao.ITaskDAO#getAllTasks()
	 */
	@SuppressWarnings("unchecked")
	public List<Tasks> getAllTasks() {
		String hql = "FROM Tasks as tsktb ORDER BY tsktb.taskId";
		return (List<Tasks>) entityManager.createQuery(hql).getResultList();
	}

	/* (non-Javadoc)
	 * @see com.taskmanager.dao.ITaskDAO#getTasksById(int)
	 */
	public Tasks getTasksById(int taskId) {
		return entityManager.find(Tasks.class, taskId);
	}

	/* (non-Javadoc)
	 * @see com.taskmanager.dao.ITaskDAO#addTask(com.taskmanager.entity.Tasks)
	 */
	public void addTask(Tasks task) {
		entityManager.persist(task);

	}

	/* (non-Javadoc)
	 * @see com.taskmanager.dao.ITaskDAO#updateTask(com.taskmanager.entity.Tasks)
	 */
	public void updateTask(Tasks task) {
		Tasks taskU = getTasksById(task.getTaskId());
		taskU.setTaskDesk(task.getTaskDesk());
		taskU.setEndDate(task.getEndDate());
		taskU.setPriority(task.getPriority());
		entityManager.flush();

	}

	/* (non-Javadoc)
	 * @see com.taskmanager.dao.ITaskDAO#deleteTask(int)
	 */
	public void deleteTask(int taskId) {
		entityManager.remove(getTasksById(taskId));

	}

	/* (non-Javadoc)
	 * @see com.taskmanager.dao.ITaskDAO#TaskExists(java.lang.String)
	 */
	public boolean TaskExists(String taskDesk) {
		String hql = "FROM task_table as atcl WHERE atcl.TaskDesk = ?";
		int count = entityManager.createQuery(hql).setParameter(1, taskDesk)
		              .getResultList().size();
		return count > 0 ? true : false;
	}

    /* (non-Javadoc)
     * @see org.springframework.data.repository.PagingAndSortingRepository#findAll(org.springframework.data.domain.Pageable)
     */
    @Override
    public Page<Tasks> findAll(Pageable pageable) {
        // TODO Auto-generated method stub
        return null;
    }

    /* (non-Javadoc)
     * @see org.springframework.data.repository.CrudRepository#save(java.lang.Object)
     */
    @Override
    public <S extends Tasks> S save(S entity) {
        // TODO Auto-generated method stub
        return null;
    }

    /* (non-Javadoc)
     * @see org.springframework.data.repository.CrudRepository#findById(java.lang.Object)
     */
    @Override
    public Optional<Tasks> findById(Long id) {
        // TODO Auto-generated method stub
        return null;
    }

    /* (non-Javadoc)
     * @see org.springframework.data.repository.CrudRepository#existsById(java.lang.Object)
     */
    @Override
    public boolean existsById(Long id) {
        // TODO Auto-generated method stub
        return false;
    }

    /* (non-Javadoc)
     * @see org.springframework.data.repository.CrudRepository#count()
     */
    @Override
    public long count() {
        // TODO Auto-generated method stub
        return 0;
    }

    /* (non-Javadoc)
     * @see org.springframework.data.repository.CrudRepository#deleteById(java.lang.Object)
     */
    @Override
    public void deleteById(Long id) {
        // TODO Auto-generated method stub
        
    }

    /* (non-Javadoc)
     * @see org.springframework.data.repository.CrudRepository#delete(java.lang.Object)
     */
    @Override
    public void delete(Tasks entity) {
        // TODO Auto-generated method stub
        
    }

    /* (non-Javadoc)
     * @see org.springframework.data.repository.CrudRepository#deleteAll(java.lang.Iterable)
     */
    @Override
    public void deleteAll(Iterable<? extends Tasks> entities) {
        // TODO Auto-generated method stub
        
    }

    /* (non-Javadoc)
     * @see org.springframework.data.repository.CrudRepository#deleteAll()
     */
    @Override
    public void deleteAll() {
        // TODO Auto-generated method stub
        
    }

    /* (non-Javadoc)
     * @see org.springframework.data.repository.query.QueryByExampleExecutor#findOne(org.springframework.data.domain.Example)
     */
    @Override
    public <S extends Tasks> Optional<S> findOne(Example<S> example) {
        // TODO Auto-generated method stub
        return null;
    }

    /* (non-Javadoc)
     * @see org.springframework.data.repository.query.QueryByExampleExecutor#findAll(org.springframework.data.domain.Example, org.springframework.data.domain.Pageable)
     */
    @Override
    public <S extends Tasks> Page<S> findAll(Example<S> example, Pageable pageable) {
        // TODO Auto-generated method stub
        return null;
    }

    /* (non-Javadoc)
     * @see org.springframework.data.repository.query.QueryByExampleExecutor#count(org.springframework.data.domain.Example)
     */
    @Override
    public <S extends Tasks> long count(Example<S> example) {
        // TODO Auto-generated method stub
        return 0;
    }

    /* (non-Javadoc)
     * @see org.springframework.data.repository.query.QueryByExampleExecutor#exists(org.springframework.data.domain.Example)
     */
    @Override
    public <S extends Tasks> boolean exists(Example<S> example) {
        // TODO Auto-generated method stub
        return false;
    }

    /* (non-Javadoc)
     * @see org.springframework.data.jpa.repository.JpaRepository#findAll()
     */
    @Override
    public List<Tasks> findAll() {
        // TODO Auto-generated method stub
        return null;
    }

    /* (non-Javadoc)
     * @see org.springframework.data.jpa.repository.JpaRepository#findAll(org.springframework.data.domain.Sort)
     */
    @Override
    public List<Tasks> findAll(Sort sort) {
        // TODO Auto-generated method stub
        return null;
    }

    /* (non-Javadoc)
     * @see org.springframework.data.jpa.repository.JpaRepository#findAllById(java.lang.Iterable)
     */
    @Override
    public List<Tasks> findAllById(Iterable<Long> ids) {
        // TODO Auto-generated method stub
        return null;
    }

    /* (non-Javadoc)
     * @see org.springframework.data.jpa.repository.JpaRepository#saveAll(java.lang.Iterable)
     */
    @Override
    public <S extends Tasks> List<S> saveAll(Iterable<S> entities) {
        // TODO Auto-generated method stub
        return null;
    }

    /* (non-Javadoc)
     * @see org.springframework.data.jpa.repository.JpaRepository#flush()
     */
    @Override
    public void flush() {
        // TODO Auto-generated method stub
        
    }

    /* (non-Javadoc)
     * @see org.springframework.data.jpa.repository.JpaRepository#saveAndFlush(java.lang.Object)
     */
    @Override
    public <S extends Tasks> S saveAndFlush(S entity) {
        // TODO Auto-generated method stub
        return null;
    }

    /* (non-Javadoc)
     * @see org.springframework.data.jpa.repository.JpaRepository#deleteInBatch(java.lang.Iterable)
     */
    @Override
    public void deleteInBatch(Iterable<Tasks> entities) {
        // TODO Auto-generated method stub
        
    }

    /* (non-Javadoc)
     * @see org.springframework.data.jpa.repository.JpaRepository#deleteAllInBatch()
     */
    @Override
    public void deleteAllInBatch() {
        // TODO Auto-generated method stub
        
    }

    /* (non-Javadoc)
     * @see org.springframework.data.jpa.repository.JpaRepository#getOne(java.lang.Object)
     */
    @Override
    public Tasks getOne(Long id) {
        // TODO Auto-generated method stub
        return null;
    }

    /* (non-Javadoc)
     * @see org.springframework.data.jpa.repository.JpaRepository#findAll(org.springframework.data.domain.Example)
     */
    @Override
    public <S extends Tasks> List<S> findAll(Example<S> example) {
        // TODO Auto-generated method stub
        return null;
    }

    /* (non-Javadoc)
     * @see org.springframework.data.jpa.repository.JpaRepository#findAll(org.springframework.data.domain.Example, org.springframework.data.domain.Sort)
     */
    @Override
    public <S extends Tasks> List<S> findAll(Example<S> example, Sort sort) {
        // TODO Auto-generated method stub
        return null;
    }

}
